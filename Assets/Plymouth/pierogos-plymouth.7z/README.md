# Plymouth

Hosts/Contains Plymouth Theme And Required Fonts.
Logo-Slider Plymouth From Gnome Look